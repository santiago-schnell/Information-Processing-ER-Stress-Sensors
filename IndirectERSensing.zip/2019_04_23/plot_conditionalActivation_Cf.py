import numpy as np
import matplotlib as mpl
mpl.use("TKAgg")
label_size = 16
mpl.rcParams['xtick.labelsize'] = label_size
mpl.rcParams['ytick.labelsize'] = label_size
import matplotlib.pyplot as plt
from scipy.integrate import quad
from scipy.special import gammaln
import mutual_information_2D_input_2isomers as mi2d
import glob
from joblib import Parallel, delayed
from plot_MI_optimization_results_2Dinput import calc_optimized_response_functions

########################################################################################
#---------------------------------------------------------------------------------------
def calcu_theta_c(theta,c0):
    return c0/theta - 1.
#---------------------------------------------------------------------------------------
def KIA(alpha,beta,gamma,c,U0):
    ''' Calculates equilibrium activation for sensor.
    '''
    u = U0/(1.+c)
    return gamma * (1. + alpha*u)/(1. + beta*c)
#---------------------------------------------------------------------------------------
def mu(N,alpha,beta,gamma,c,U0):
    ''' Calculates mean value for active sensors in the hybrid model. Setting alpha=0 gives
        mean value of indirect model, and setting beta=0 gives mean value of direct model.
    '''
    K = KIA(alpha,beta,gamma,c,U0)
    mu = N*K/(1.+K)

    return mu
#---------------------------------------------------------------------------------------
def pna_c_saddlepoint(n,N,alpha,beta,gamma,c,U0min,U0max):
    ''' Saddlepoint approximation for the conditional probability of activation for the 
        general (hybrid) model. Setting alpha=0 will give results for the indirect model.
    '''
    muMin = mu(N,alpha,beta,gamma,c,U0min)
    muMax = mu(N,alpha,beta,gamma,c,U0max)

    pna = 0.0
    if n>=muMin:
        if n <= muMax:

            pna = (N-muMax)*(N-muMin) / ((muMax-muMin)*(N-n)**2.)

    return pna 

#---------------------------------------------------------------------------------------
def mean_act_saddlepoint(u,N,alpha,beta,gamma,c0min,c0max):
    ''' Calculates the mean activation as a function of u for the saddle point
        approximation fo the conditional activation probability distribution.
    '''
    muMin = mu(N,alpha,beta,gamma,u,c0max)
    muMax = mu(N,alpha,beta,gamma,u,c0min)

    na_mean = (muMax-muMin)/np.log(muMax/muMin)

    return na_mean
#---------------------------------------------------------------------------------------
#---------------------------------------------------------------------------------------
if __name__=="__main__":

    ###################################
    # Set parameters

    # parameters for uf case point (8,0)
    tag = "Cf_8_0"
    gamma_dir = 8.74116490e-04
    alpha_dir = 1.55568619e+04
    beta_dir = 0.

    gamma_ind = 1.00376069e+06
    alpha_ind = 0.
    beta_ind = 4.43615950e+01

    gamma_hyb = 25725.11030426
    alpha_hyb = 592.00370803
    beta_hyb = 39.96516102

    N = 101
    na = range(N)

    u0min = 1000.
    u0max = 2000.

    ###################################
    # plot approximate heatmap
    crange = np.linspace(0.,65000.,200)

    vmin = 0.0
    vmax = 0.10
    cmap = 'viridis'

    C,NA = np.meshgrid(crange,na)
    pna_c_dir = lambda ci,nai: pna_c_saddlepoint(nai,N,alpha_dir,beta_dir,gamma_dir,ci,u0min,u0max)
    pna_c_hyb = lambda ci,nai: pna_c_saddlepoint(nai,N,alpha_hyb,beta_hyb,gamma_hyb,ci,u0min,u0max)
    pna_c_ind = lambda ci,nai: 0.#pna_u_saddlepoint(nai,N,alpha_dir,beta_dir,gamma_dir,ui,c0min,c0min+100.)

    PNA_C_Ind = np.zeros(C.shape)
    PNA_C_Hyb = np.zeros(C.shape)
    PNA_C_Dir = np.zeros(C.shape)
    for i in range(C.shape[0]):
        for j in range(C.shape[1]):
            PNA_C_Ind[i,j] = pna_c_ind(C[i,j],NA[i,j])
            PNA_C_Hyb[i,j] = pna_c_hyb(C[i,j],NA[i,j])
            PNA_C_Dir[i,j] = pna_c_dir(C[i,j],NA[i,j])

    figHM, axHM = plt.subplots(1,3,figsize=(12,4))

    #----- Plot Indirect -----#
    pcInd = axHM[1].pcolormesh(C,NA,PNA_C_Ind,vmin=vmin,vmax=vmax,cmap=cmap)
    #cbarIND = figHM.colorbar(pcInd,ax=axHM[0])
    #cbarIND.set_label(r'$p(n_{{A}}|u)$',fontsize=16)

    mu_ind = mu(N,alpha_ind,beta_ind,gamma_ind,crange,u0max)
    color = plt.get_cmap(cmap)(1.0)
    axHM[1].plot(crange,mu_ind,linewidth=2,color=color)

    axHM[1].set_xlabel(r'$c$',fontsize=18)

    #----- Plot Direct -----#
    pcDir = axHM[0].pcolormesh(C,NA,PNA_C_Dir,vmin=vmin,vmax=vmax,cmap=cmap)
    #cbarIND = figHM.colorbar(pcInd,ax=axHM[1])
    #cbarIND.set_label(r'$p(n_{{A}}|u)$',fontsize=16)

    axHM[0].set_xlabel(r'$c$',fontsize=18)
    axHM[0].set_ylabel(r'$n_{{A}}$',fontsize=18)

    #----- Plot Hybrid ------#
    pcHyb = axHM[2].pcolormesh(C,NA,PNA_C_Hyb,vmin=vmin,vmax=vmax,cmap=cmap)
    #cbarHYB = figHM.colorbar(pcHyb,ax=axHM[1])
    #cbarHYB.set_label(r'$p(n_{{A}}|u)$',fontsize=16)

    axHM[2].set_xlabel(r'$c$',fontsize=18)
    #axHM[1].set_ylabel(r'$n_{{A}}$',fontsize=18)


    #----- Set axis range for indirect -----#
    ylims = axHM[2].get_ylim()
    axHM[1].set_ylim(ylims)
    #axHM[1].set_ylim((0,100))

    #----- Add Colorbar -----#

    figHM.tight_layout()

    figHM.subplots_adjust(right=0.8)
    cbar_ax = figHM.add_axes([0.85, 0.20, 0.03, 0.7])
    cbar = figHM.colorbar(pcHyb, cax=cbar_ax)
    cbar.set_label(r'$p(n_{{A}}|c)$',fontsize=16)


    '''
    ###################################
    # plot approximate pna_u for different dC0
    uval = 20000.
    #deltaC0 = np.logspace(2,4,3)
    deltaC0 = np.array([100.,500.,5000.])

    figdC0, axdC0 = plt.subplots(1,1)
    pna_u_c0 = lambda nai,c0mini,c0maxi: pna_u_saddlepoint(nai,N,0.,beta_ind,gamma_ind,uval,c0mini,c0maxi)
    for dC0i in deltaC0:
        cmaxi = c0min + dC0i
        pna_ui = [pna_u_c0(nai,c0min,cmaxi) for nai in na]
        
        axdC0.plot(na,pna_ui,linewidth=2,label=r'$\Delta C_{{0}}={}$'.format(dC0i))

    axdC0.legend()

    axdC0.set_xlabel(r'$n_{A}$',fontsize=18)
    axdC0.set_ylabel(r'$p(n_{A}|u)$',fontsize=18)

    figdC0.tight_layout()

    ###################################
    # plot approximate mean activation
    mean_dir = lambda c: mean_act_saddlepoint(c,N,alpha_ind,beta_ind,gamma_ind,c0min,c0max)
    mean_hyb = lambda c: mean_act_saddlepoint(c,N,alpha_hyb,beta_hyb,gamma_hyb,c0min,c0max)

    figMeanAct, axMeanAct = plt.subplots(1,1)
    axMeanAct.plot(urange,mean_ind(urange),linewidth=2,label=r'Indirect')
    axMeanAct.plot(urange,mean_hyb(urange),linewidth=2,label=r'Hybrid')

    axMeanAct.set_xlabel(r'$u$',fontsize=18)
    axMeanAct.set_ylabel(r'$\langle n_{A} \rangle_{sp}$',fontsize=18)
    axMeanAct.legend()

    figMeanAct.tight_layout()
    '''
    ########################################################################################################
    ########################################################################################################
    ###################################
    # Save figures to files
    save_bool = 1
    if save_bool:
        #figHM.savefig('./Figures/ApproxHeatMap_indirect'+tag+'.eps',edgecolor='black')
        figHM.savefig('./Figures/ApproxHeatMap_indirect'+tag+'.pdf')
        #figdC0.savefig('./Figures/Pna_uSlices_deltaC0'+tag+'.eps',edgecolor='black')

    plt.show()
