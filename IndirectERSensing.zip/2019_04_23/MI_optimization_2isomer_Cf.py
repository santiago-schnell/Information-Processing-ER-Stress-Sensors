import numpy as np
import matplotlib as mpl
mpl.use("TKAgg")
label_size = 16
mpl.rcParams['xtick.labelsize'] = label_size
mpl.rcParams['ytick.labelsize'] = label_size
import matplotlib.pyplot as plt
from scipy.optimize import minimize
import mutual_information_2D_input_2isomers as mi2d
import copy
import time
from joblib import Parallel, delayed
import os
import datetime

#######################################################################################################################
#----------------------------------------------------------------------
# Define function wrappers for maximization of mutual information
#----------------------------------------------------------------------
def MI_dir_wrapper(params,inputs,Kd,N_I,nbins=100):
    #params = [gamma,alpha]
    KaIA = lambda u0,b0: mi2d.KaIA_dir(u0,b0,Kd,params[0],params[1])	
    MI = mi2d.calc_2isomer_mutual_information_general(N_I,inputs,KaIA,Kd,nbins=nbins)
    return -MI
#----------------------------------------------------------------------
def MI_indir_wrapper(params,inputs,Kd,N_I,nbins=100):
    # params = [gamma,beta]
    KaIA = lambda u0,b0: mi2d.KaIA_indir(u0,b0,Kd,params[0],params[1])	
    MI = mi2d.calc_2isomer_mutual_information_general(N_I,inputs,KaIA,Kd,nbins=nbins)
    return -MI
#----------------------------------------------------------------------
def MI_hyb_wrapper(params,inputs,Kd,N_I,nbins=100):
    # params = [gamma,alpha,beta]
    KaIA = lambda u0,b0: mi2d.KaIA_hyb(u0,b0,Kd,params[0],params[1],params[2])	
    MI = mi2d.calc_2isomer_mutual_information_general(N_I,inputs,KaIA,Kd,nbins=nbins)
    return -MI
#----------------------------------------------------------------------
#----------------------------------------------------------------------
def optimize_all_mechanisms(inputs, Kd, N_I, k0 = [1.,1e-1,1e-1],nbins=100,refine_hyb=True):

    args = (inputs,Kd,N_I,nbins)

    # Bounds for optimization
    bounds_dir = [(1.e-6,np.inf),(1.e-6,np.inf)]
    bounds_indir = [(1.e-6,np.inf),(1.e-6,np.inf)]
    bounds_hyb = [(1e-6,np.inf),(1e-6,np.inf),(1.e-6,np.inf)]

    options = {'disp':False}

    res_dir = minimize(MI_dir_wrapper,[k0[0],k0[1]],args=args,method='L-BFGS-B',bounds=bounds_dir,options=options)
    res_indir = minimize(MI_indir_wrapper,[k0[0],k0[2]],args=args,method='L-BFGS-B',bounds=bounds_indir,options=options)
    res_hyb = minimize(MI_hyb_wrapper,k0,args=args,method='L-BFGS-B',bounds=bounds_hyb,options=options)
    if refine_hyb:
        k0_dir = [res_dir.x[0],res_dir.x[1],0.]
        res_hyb_from_dir = minimize(MI_hyb_wrapper,k0_dir,args=args,method='L-BFGS-B',bounds=bounds_hyb,options=options)
        k0_indir = [res_indir.x[0],0.0,res_indir.x[1]]
        res_hyb_from_indir = minimize(MI_hyb_wrapper,k0_indir,args=args,method='L-BFGS-B',bounds=bounds_hyb,options=options)

        print("*******")
        print(res_dir.fun,res_indir.fun,res_hyb.fun,res_hyb_from_dir.fun,res_hyb_from_indir.fun)
        hyb_results = [res_hyb, res_hyb_from_dir, res_hyb_from_indir]
        hyb_mi = [res.fun for res in hyb_results]
        val, ind = min((val,ind) for (ind,val) in enumerate(hyb_mi))
        res_hyb = hyb_results[ind]

        print(res_hyb.fun)
    return [res_dir,res_indir,res_hyb]
#----------------------------------------------------------------------
def multistart_optimize_all_mechanisms(inputs, Kd, N_I, nbins=100, refine_hyb=True, n=3):

    # initial guess for off-rates
    k_init = np.logspace(-4,4,n)
    k0vals = []
    for ki in k_init:
        for kj in k_init:
            k0vals.append([ki,kj,kj])

    args = (inputs,Kd,N_I,nbins)

    # Bounds for optimization
    bounds_dir = [(1.e-6,np.inf),(1.e-6,np.inf)]
    bounds_indir = [(1.e-6,np.inf),(1.e-6,np.inf)]
    bounds_hyb = [(1e-6,np.inf),(1e-6,np.inf),(1.e-6,np.inf)]

    options = {'disp':False}

    min_dir = None
    min_indir = None
    min_hyb = None

    def parfunc(ki):
        res_dir = minimize(MI_dir_wrapper,[ki[0],ki[1]],args=args,method='L-BFGS-B',bounds=bounds_dir,options=options)
        res_indir = minimize(MI_indir_wrapper,[ki[0],ki[2]],args=args,method='L-BFGS-B',bounds=bounds_indir,options=options)
        res_hyb = minimize(MI_hyb_wrapper,ki,args=args,method='L-BFGS-B',bounds=bounds_hyb,options=options)
        if refine_hyb:
            k0_dir = [res_dir.x[0],res_dir.x[1],0.]
            res_hyb_from_dir = minimize(MI_hyb_wrapper,k0_dir,args=args,method='L-BFGS-B',bounds=bounds_hyb,options=options)
            k0_indir = [res_indir.x[0],0.0,res_indir.x[1]]
            res_hyb_from_indir = minimize(MI_hyb_wrapper,k0_indir,args=args,method='L-BFGS-B',bounds=bounds_hyb,options=options)

            print("*******")
            print(res_dir.fun,res_indir.fun,res_hyb.fun,res_hyb_from_dir.fun,res_hyb_from_indir.fun)
            hyb_results = [res_hyb, res_hyb_from_dir, res_hyb_from_indir]
            hyb_mi = [res.fun for res in hyb_results]
            val, ind = min((val,ind) for (ind,val) in enumerate(hyb_mi))
            res_hyb = hyb_results[ind]

            print(res_hyb.fun)

        return [res_dir,res_indir,res_hyb]

    n_jobs = min(11,len(k0vals))
    results = Parallel(n_jobs=n_jobs)(map(delayed(parfunc), k0vals))

    res_dir = [resi[0] for resi in results]
    res_indir = [resi[1] for resi in results]
    res_hyb = [resi[2] for resi in results]

    min_dir_index = np.argmin(np.array([res_diri.fun for res_diri in res_dir]))
    min_indir_index = np.argmin(np.array([res_indiri.fun for res_indiri in res_indir]))
    min_hyb_index = np.argmin(np.array([res_hybi.fun for res_hybi in res_hyb]))

    min_dir = res_dir[min_dir_index]
    min_indir = res_indir[min_indir_index]
    min_hyb = res_hyb[min_hyb_index]

    '''
    for ki in k0vals:
        res_dir = minimize(MI_dir_wrapper,[ki[0],ki[1]],args=args,method='L-BFGS-B',bounds=bounds_dir,options=options)
        res_indir = minimize(MI_indir_wrapper,[ki[0],ki[2]],args=args,method='L-BFGS-B',bounds=bounds_indir,options=options)
        res_hyb = minimize(MI_hyb_wrapper,ki,args=args,method='L-BFGS-B',bounds=bounds_hyb,options=options)
        if refine_hyb:
            k0_dir = [res_dir.x[0],res_dir.x[1],0.]
            res_hyb_from_dir = minimize(MI_hyb_wrapper,k0_dir,args=args,method='L-BFGS-B',bounds=bounds_hyb,options=options)
            k0_indir = [res_indir.x[0],0.0,res_indir.x[1]]
            res_hyb_from_indir = minimize(MI_hyb_wrapper,k0_indir,args=args,method='L-BFGS-B',bounds=bounds_hyb,options=options)

            print("*******")
            print(res_dir.fun,res_indir.fun,res_hyb.fun,res_hyb_from_dir.fun,res_hyb_from_indir.fun)
            hyb_results = [res_hyb, res_hyb_from_dir, res_hyb_from_indir]
            hyb_mi = [res.fun for res in hyb_results]
            val, ind = min((val,ind) for (ind,val) in enumerate(hyb_mi))
            res_hyb = hyb_results[ind]

            print(res_hyb.fun)

        if (min_dir==None) or (min_dir.fun > res_dir.fun):
            min_dir = res_dir
        if (min_indir==None) or (min_indir.fun > res_indir.fun):
            min_indir = res_indir
        if (min_hyb==None) or (min_hyb.fun > res_hyb.fun):
            min_hyb = res_hyb
    '''

    return [min_dir,min_indir,min_hyb]


#----------------------------------------------------------------------
#----------------------------------------------------------------------
if __name__=="__main__":

    ###### Parameters ######
    N_I = 100		# Copy number of sensor molecules
    Kd = 1.0 		# U+B<->UB reaction is normalized by Kd_UB such that this value is 1

    nbins = 100
    #k0 = [1.e-4,1e3,1e3]
    k0 = [1.,1e-1,1e-1]
    #k0 = [1.,1e-3,1e-3]		# Initial guess for parameters in optimization

    ###### Define input distribution ######
    Nx = 100
    Ny = 100

    ## Set input type with either (X,Y,Z) = (U0,B0,THETA(X,Y)=Cf) or (X,Y,Z) = (THETA=Cf,U0,B0) ##
    XYmin = 1.0e4
    input_type = 1			
    if input_type == 0:			# implies X=U0,Y=B0
        Xmin = np.array([0.5e3,1e3,2e3])
        Xmax_factor = np.array([2.,10.,100.])
        zfunc = lambda x,y: mi2d.ueq(x,y,Kd)
        order = [0,1,2]	# sets the ordering of the indexes for output of generate_input_distributions

    elif input_type == 1:		# implies X=Cf,Y=U0
        Xmin = [XYmin]
        Xmax_factor = np.logspace(np.log10(2.0),2.,10) #np.array([2.,10.,100.])
        zfunc = lambda x,y: mi2d.B0eq_from_b_U0(x,y,Kd) # x=cf,y=u0,z=b0
        order = [1,2,0]	# [cf,U0,B0] -> [U0,B0,cf] sets the ordering of the indexes for output of generate_input_distributions


    Xminmax = [] 
    for Xmini in Xmin:
        for Xfact in Xmax_factor:
            Xminmax.append((Xmini,Xmini*Xfact))
    Xminmax = np.array(Xminmax)

    Ymin = [XYmin]
    Ymax_factor = np.logspace(np.log10(2.0),2.,10)
    Yminmax = [] 
    for Ymini in Ymin:
        for Yfact in Ymax_factor:
            Yminmax.append((Ymini,Ymini*Yfact))
    Yminmax = np.array(Yminmax)

    # Or specify directly
    #Xminmax = [(1000.0,4770.664608946602)]
    #Yminmax = [(1000.0,64747.88028695254)]

    inputs = []
    params = []
    for (Ymini,Ymaxi) in Yminmax:
        Yvals = np.linspace(Ymini,Ymaxi,Ny)
        for (Xmini,Xmaxi) in Xminmax:
            Xvals = np.linspace(Xmini,Xmaxi,Nx)
            inputi = mi2d.generate_input_distributions(Xvals,Yvals,zfunc)
            inputs.append([inputi[i] for i in order])
            params.append([Xmini,Xmaxi,Ymini,Ymaxi,N_I,Nx,Ny,nbins,input_type])

    # Set up directory for output data
    now = datetime.datetime.now()
    dirname = "./OptData/THETA_Cf/"+now.strftime("%Y_%m_%d-%H%M%S") #2Dinput_input{}/B0min{}_B0max{}/".format(input_type,Ymin,Ymax)
    if not os.path.exists(dirname):
        os.makedirs(dirname)

    #---------------------------------------------------- 
    def par_func(arg):
        input_i = arg[0]
        param_i = arg[1]
        # Optimize parameters (gamma,alpha,beta) for maximal mutual information
        refine_hyb = True
        #results = optimize_all_mechanisms(input_i,Kd,N_I,k0,nbins)
        results = multistart_optimize_all_mechanisms(input_i,Kd,N_I,nbins,refine_hyb,3)
        data_list = []
        for j in range(len(results)):
            data = copy.deepcopy(param_i)#[U0min[i],U0max[i],B0min,B0max,N_I,Nu,Nb,nbins]
            for res_xi in results[j].x:
                data.append(res_xi)
            data_list.append(np.asarray(data))
        print("***************************")
        print(datetime.datetime.now())
        print(param_i)
        return data_list
    #---------------------------------------------------- 

    tstart = time.time()
    # Loop over input distributions
    mechnames = ["dir","indir","hyb"]
    n_jobs = 1
    if n_jobs==1:
        results = [par_func(xi) for xi in zip(inputs,params)]
    else:
        results = Parallel(n_jobs=n_jobs)(map(delayed(par_func), zip(inputs,params)))
    
    data_list = [[] for i in range(len(mechnames))]
    for ri in results:
        for j in range(len(ri)):
            data_list[j].append(ri[j])

    topt = time.time() - tstart
    print("******************************************")
    print("Optimization time: {:2f} sec for {} parameter sets".format(topt,len(inputs)))
    print("******************************************")

    # Save results to data files
    mechnames = ["dir","indir","hyb"]

    for name,res in zip(mechnames,data_list):
        filename = dirname+"/"+name+"_opt_results.npy"
        data = np.vstack(res)
        np.save(filename,data)

    #---------------------------------------------------- 
