import numpy as np
import matplotlib as mpl
mpl.use("TKAgg")
label_size = 16
mpl.rcParams['xtick.labelsize'] = label_size
mpl.rcParams['ytick.labelsize'] = label_size
import matplotlib.pyplot as plt
#import mutual_information_2D_input_2isomers as mi2d
#import glob
from joblib import Parallel, delayed
#from plot_MI_optimization_results_2Dinput import calc_optimized_response_functions
from plot_MI_optimization_results_2Dinput_THETA_Cf import calc_optimized_response_functions

###############################################################################################
#----------------------------------------------------------------------
#----------------------------------------------------------------------
if __name__=="__main__":

    mechnames = ["dir","indir","hyb"]
    #basedir = "./OptData/Convergence/2019_03_11-140543/"
    basedir = "./OptData/Convergence/Cf/2019_03_12-130955/"
    filenames = [basedir+mechname+"_opt_results.npy" for mechname in mechnames]
    datasets = [np.load(filename) for filename in filenames]
    data = dict(zip(mechnames,datasets))

    #--------------------------------------------------------------------------
    ##### Parse data for plotting results ######

    ##### Calculate information for results to be plotted #####
    def parfunc(ind):
        return calc_optimized_response_functions(data,ind)

    N = data['dir'][:,-4]

    n_jobs = min(data['dir'].shape[0],10)
    results = Parallel(n_jobs=n_jobs)(map(delayed(parfunc),range(data['dir'].shape[0])))

    ##### Plot MI vs N (nbins, Nu,Nc) #####
    fig1,ax1 = plt.subplots(1,2,figsize=(8,4))

    Idir = []
    Iindir = []
    Ihyb = []

    for i,resi in enumerate(results):
        Idirj,mean_dir,std_dir,Pa_u_dir,bin_edges_dir = resi[0]
        Iindirj,mean_indir,std_indir,Pa_u_indir,bin_edges_indir = resi[1]
        Ihybj,mean_hyb,std_hyb,Pa_u_hyb,bin_edges_hyb = resi[2]

        Idir.append(Idirj)
        Iindir.append(Iindirj)
        Ihyb.append(Ihybj)


    ErrDir = [abs(mi-Idir[-1])/(Idir[-1]) for mi in Idir]
    ErrInd = [abs(mi-Iindir[-1])/(Iindir[-1]) for mi in Iindir]
    ErrHyb = [abs(mi-Ihyb[-1])/(Ihyb[-1]) for mi in Ihyb]

    ax1[0].plot(N,Idir,"-*",linewidth=2,label="direct")
    ax1[0].plot(N,Iindir,"-^",linewidth=2,label="indirect")
    ax1[0].plot(N,Ihyb,"-s",linewidth=2,label="hybrid")

    ax1[1].plot(N[:-1],ErrDir[:-1],"-*",linewidth=2,)
    ax1[1].plot(N[:-1],ErrInd[:-1],"-^",linewidth=2,)
    ax1[1].plot(N[:-1],ErrHyb[:-1],"-s",linewidth=2,)

    ax1[0].legend()
    ax1[0].set_xlabel('N', fontsize=18)
    ax1[0].set_ylabel('Mutual Information',fontsize=18)

    ax1[1].set_xlabel('N', fontsize=18)
    ax1[1].set_ylabel('Error',fontsize=18)
    ax1[1].set_yscale('log')

    fig1.tight_layout()

    fig1.savefig("./Figures/Convergence_Cf.eps",edgecolor="black")

    plt.show()
