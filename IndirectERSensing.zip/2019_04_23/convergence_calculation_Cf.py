import numpy as np
import matplotlib as mpl
mpl.use("TKAgg")
label_size = 16
mpl.rcParams['xtick.labelsize'] = label_size
mpl.rcParams['ytick.labelsize'] = label_size
import matplotlib.pyplot as plt
from scipy.optimize import minimize
import mutual_information_2D_input_2isomers as mi2d
import MI_optimization_2isomer_Cf as mioptC
import copy
import time
from joblib import Parallel, delayed
import os
import datetime

#------------------------------------------------------------------------------------
#------------------------------------------------------------------------------------

#------------------------------------------------------------------------------------
#------------------------------------------------------------------------------------
if __name__=="__main__":

    ###### Parameters ######
    N_I = 100		# Copy number of sensor molecules
    Kd = 1.0 		# U+B<->UB reaction is normalized by Kd_UB such that this value is 1

    k0 = [1.,1e-1,1e-1]

    input_type = 1
    zfunc = lambda x,y: mi2d.B0eq_from_b_U0(x,y,Kd) # x=cf,y=u0,z=b0
    order = [1,2,0]	# [cf,U0,B0] -> [U0,B0,cf] sets the ordering of the indexes for output of generate_input_distributions

    ###### Define input distribution ######
    Xminmax = (1000.0,1e4)
    Yminmax = (1000.0,1e4)

    Nvals = [10,50,100,200]

    inputs = []
    params = []
    for Ni in Nvals:

        nbins = Ni
        Nx = Ni
        Ny = Ni

        Xvals = np.linspace(Xminmax[0],Xminmax[1],Nx)
        Yvals = np.linspace(Yminmax[0],Yminmax[1],Ny)

        inputi = mi2d.generate_input_distributions(Xvals,Yvals,zfunc)
        inputs.append([inputi[i] for i in order])
        params.append([Xminmax[0],Xminmax[1],Yminmax[0],Yminmax[1],N_I,Nx,Ny,nbins,input_type])

    # Set up directory for output data
    now = datetime.datetime.now()
    dirname = "./OptData/Convergence/Cf/"+now.strftime("%Y_%m_%d-%H%M%S") #2Dinput_input{}/B0min{}_B0max{}/".format(input_type,Ymin,Ymax)
    if not os.path.exists(dirname):
        os.makedirs(dirname)

    #---------------------------------------------------- 
    def par_func(arg):
        input_i = arg[0]
        param_i = arg[1]
        # Optimize parameters (gamma,alpha,beta) for maximal mutual information
        refine_hyb = True
        results = mioptC.multistart_optimize_all_mechanisms(input_i,Kd,N_I,nbins,refine_hyb,3)
        data_list = []
        for j in range(len(results)):
            data = copy.deepcopy(param_i)#[U0min[i],U0max[i],B0min,B0max,N_I,Nu,Nb,nbins]
            for res_xi in results[j].x:
                data.append(res_xi)
            data_list.append(np.asarray(data))
        print("***************************")
        print(datetime.datetime.now())
        print(param_i)
        return data_list
    #---------------------------------------------------- 

    tstart = time.time()
    # Loop over inputs
    mechnames = ["dir","indir","hyb"]
    n_jobs = min(10,len(inputs))
    results = Parallel(n_jobs=n_jobs)(map(delayed(par_func), zip(inputs,params)))
    data_list = [[] for i in range(len(mechnames))]
    for ri in results:
        for j in range(len(ri)):
            data_list[j].append(ri[j])

    topt = time.time() - tstart
    print("******************************************")
    print("Optimization time: {:2f} sec for {} parameter sets".format(topt,len(inputs)))
    print("******************************************")

    # Save results to data files
    mechnames = ["dir","indir","hyb"]

    for name,res in zip(mechnames,data_list):
        filename = dirname+"/"+name+"_opt_results.npy"
        data = np.vstack(res)
        np.save(filename,data)
