import numpy as np
import matplotlib as mpl
mpl.use("TKAgg")
label_size = 16
mpl.rcParams['xtick.labelsize'] = label_size
mpl.rcParams['ytick.labelsize'] = label_size
import matplotlib.pyplot as plt
import mutual_information_2D_input_2isomers as mi2d
import glob
from joblib import Parallel, delayed
from plot_MI_optimization_results_2Dinput import calc_optimized_response_functions

###############################################################################################
#----------------------------------------------------------------------
#----------------------------------------------------------------------
if __name__=="__main__":

    mechnames = ["dir","indir","hyb"]
    #basedir = "./OptData/2018_12_15-161202/"
    #basedir = "./OptData/2018_12_16-174554/"
    basedir = "./OptData/2018_12_18-173216/"
    filenames = [basedir+mechname+"_opt_results.npy" for mechname in mechnames]
    datasets = [np.load(filename) for filename in filenames]
    data = dict(zip(mechnames,datasets))
    for key in data:
        print(key)
        print(data[key])
    #--------------------------------------------------------------------------
    ##### Parse data for plotting results ######

    B0min_plot_val = 2.0e2
    B0max_plot_val = B0min_plot_val*100.

    plot_umax_factors = [2.,10.,100.]
    plot_inds = [[] for i in plot_umax_factors]
    plot_umins = [[] for i in plot_umax_factors]
    for i in range(data['dir'].shape[0]):
        umin = data['dir'][i,0]
        umax = data['dir'][i,1]
        B0min = data['dir'][i,2]
        B0max = data['dir'][i,3]
        umax_factor = umax/umin
        for j,maxfacti in enumerate(plot_umax_factors):
            if (int(umax_factor) == int(maxfacti)):
                if (B0min==B0min_plot_val):
                    if (B0max==B0max_plot_val):
                        plot_inds[j].append(i)
                        plot_umins[j].append(umin)

    ##### Calculate information for results to be plotted #####
    def parfunc(ind):
        return calc_optimized_response_functions(data,ind)

    results = []
    for plot_inds_j in plot_inds:
        n_jobs = max(len(plot_inds_j),9)
        results.append(Parallel(n_jobs=n_jobs)(map(delayed(parfunc),plot_inds_j)))
    #results = [Parallel(n_jobs=max(len(plot_inds_j),9)(map(delayed(parfunc),plot_inds_j))) for plot_inds_j in plot_inds]
    ##### Plot MI vs umin #####
    fig1,ax1 = plt.subplots(1,3,figsize=(12,4))

    for i,(resi,axi) in enumerate(zip(results,ax1)):
        umins = plot_umins[i]
        Idir = []
        Iindir = []
        Ihyb = []
        for j,resij in enumerate(resi):
            Idirj,mean_dir,std_dir,Pa_u_dir,bin_edges_dir = resij[0]
            Iindirj,mean_indir,std_indir,Pa_u_indir,bin_edges_indir = resij[1]
            Ihybj,mean_hyb,std_hyb,Pa_u_hyb,bin_edges_hyb = resij[2]

            Idir.append(Idirj)
            Iindir.append(Iindirj)
            Ihyb.append(Ihybj)

        axi.plot(umins,Idir,"-*",label="direct")
        axi.plot(umins,Iindir,"-^",label="indirect")
        axi.plot(umins,Ihyb,"-s",label="hybrid")

        axi.set_xlabel(r"$U_{f,\min}$",fontsize=18)
        #axi.set_ylabel(r"$I[u;n_A]$",fontsize=18)

        axi.set_title(r"$U_{{f,\max}}={}\times U_{{f,\min}}$".format(plot_umax_factors[i]))

        axi.set_xscale('log')

    ax1[0].set_ylabel(r"$I[u;n_A]$ bits",fontsize=18)
    ax1[0].legend()
    ax1[1].get_yaxis().set_ticks([])
    ax1[2].get_yaxis().set_ticks([])

    ymin = min([axi.get_ylim()[0] for axi in ax1])
    ymax = max([axi.get_ylim()[1] for axi in ax1])

    for axi in ax1:
        axi.set_ylim((ymin,ymax))

    fig1.tight_layout()
    plt.show()
