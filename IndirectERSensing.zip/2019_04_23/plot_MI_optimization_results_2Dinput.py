import numpy as np
import matplotlib as mpl
mpl.use("TKAgg")
label_size = 16
mpl.rcParams['xtick.labelsize'] = label_size
mpl.rcParams['ytick.labelsize'] = label_size
import matplotlib.pyplot as plt
import mutual_information_2D_input_2isomers as mi2d
import glob
from joblib import Parallel, delayed
#----------------------------------------------------------------------
def calc_optimized_response_functions(data,ind):

    Xmin = data['dir'][ind,0]
    Xmax = data['dir'][ind,1]
    Ymin = int(data['dir'][ind,2])
    Ymax = data['dir'][ind,3]
    #k_on = data['dir'][ind,4]
    N_I = int(data['dir'][ind,4])
    Nx = int(data['dir'][ind,5])
    Ny = int(data['dir'][ind,6])
    nbins = int(data['dir'][ind,7])
    input_type = int(data['dir'][ind,8])
    Kd = 1.

    # Recreate input distributions
    Xvals = np.linspace(Xmin,Xmax,Nx)   
    Yvals = np.linspace(Ymin,Ymax,Ny)
    if input_type == 0:			# implies X=U0,Y=B0
        zfunc = lambda x,y: mi2d.ueq(x,y,Kd)
        order = [0,1,2]	# sets the ordering of the indexes for output of generate_input_distributions
    elif input_type == 1:		# implies X=Uf,Y=B0
        zfunc = lambda x,y: mi2d.U0eq(x,y,Kd)
        order = [2,1,0]	# sets the ordering of the indexes for output of generate_input_distributions

    inputi = mi2d.generate_input_distributions(Xvals,Yvals,zfunc)
    inputs = [inputi[i] for i in order]
    #inputs = [np.linspace(Umin,Umax,Nu),np.linspace(B0min,B0max,Nb)]

    return_extras = True

    KaIAdir = lambda u0,b0: mi2d.KaIA_dir(u0,b0,Kd,data['dir'][ind,-2],data['dir'][ind,-1])	
    Idir, extras_dir = mi2d.calc_2isomer_mutual_information(N_I,inputs,KaIAdir,Kd,nbins=nbins,return_extras=return_extras)
    Pa_u_dir = extras_dir[0]
    bin_edges_dir = extras_dir[1]

    KaIAind = lambda u0,b0: mi2d.KaIA_indir(u0,b0,Kd,data['indir'][ind,-2],data['indir'][ind,-1])	
    Iindir, extras_indir = mi2d.calc_2isomer_mutual_information(N_I,inputs,KaIAind,Kd,nbins=nbins,return_extras=return_extras)
    Pa_u_indir = extras_indir[0]
    bin_edges_indir = extras_indir[1]

    KaIAhyb = lambda u0,b0: mi2d.KaIA_hyb(u0,b0,Kd,data['hyb'][ind,-3],data['hyb'][ind,-2],data['hyb'][ind,-1])	
    Ihyb, extras_hyb = mi2d.calc_2isomer_mutual_information(N_I,inputs,KaIAhyb,Kd,nbins=nbins,return_extras=return_extras)
    Pa_u_hyb = extras_hyb[0]
    bin_edges_hyb = extras_hyb[1]

    mean_dir,std_dir = mi2d.calc_mean_std_Na_vs_uf(N_I,Pa_u_dir,bin_edges_dir)

    mean_indir,std_indir = mi2d.calc_mean_std_Na_vs_uf(N_I,Pa_u_indir,bin_edges_indir)

    mean_hyb,std_hyb = mi2d.calc_mean_std_Na_vs_uf(N_I,Pa_u_hyb,bin_edges_hyb)

    data_out = [[Idir,mean_dir,std_dir,Pa_u_dir,bin_edges_dir],
                [Iindir,mean_indir,std_indir,Pa_u_indir,bin_edges_indir],
                [Ihyb,mean_hyb,std_hyb,Pa_u_hyb,bin_edges_hyb]]

    return data_out

#----------------------------------------------------------------------
#----------------------------------------------------------------------
if __name__=="__main__":

    mechnames = ["dir","indir","hyb"]
    #basedir = "./OptData/2Dinput_input0/"
    #basedir = "./OptData/2Dinput_input1/"
    #basedir = "./OptData/2Dinput_input1/20181207_192104/"
    basedir = "./OptData/2Dinput_input1/B0min2000.0_B0max20000.0/"
    #basedir = "./OptData/2Dinput_input1/B0min2000.0_B0max200000.0/"
    filenames = [basedir+mechname+"_opt_results.npy" for mechname in mechnames]
    datasets = [np.load(filename) for filename in filenames]
    data = dict(zip(mechnames,datasets))

    print(data['dir'].shape)

    #--------------------------------------------------------------------------
    ##### Plot optimization results ######

    #plot_umin_vals = [0.5e3,1.0e3,2.0e3]
    plot_umin_vals = [0.1e3,0.5e3,1.0e3]
    plot_umax_factors = [2.,10.,100.]
    plot_inds = []
    for i in range(data['dir'].shape[0]):
        umin = data['dir'][i,0]
        umax = data['dir'][i,1]
        umax_factor = umax/umin
        if (umin in plot_umin_vals):
            if (int(100.*umax_factor) in [int(100*pfi) for pfi in  plot_umax_factors]):
                    plot_inds.append(i)
    print(plot_inds)
    n_plots = len(plot_inds)#len(range(0,data['dir'].shape[0],30))
    n_umin = len(plot_umin_vals)
    n_umax = len(plot_umax_factors)
    figsize = (3*n_umin,3*n_umax)
    fig,axs = plt.subplots(n_umax,n_umin,figsize=figsize)
    axs = axs.reshape(len(plot_inds),)

    def parfunc(ind):
        return calc_optimized_response_functions(data,ind)

    results = Parallel(n_jobs=9)(map(delayed(parfunc),plot_inds))
    
    for i,(resi, axi) in enumerate(zip(results,axs)):
        #plot_optimized_response_functions(data,ind,axi)

        Idir,mean_dir,std_dir,Pa_u_dir,bin_edges_dir = resi[0]
        Iindir,mean_indir,std_indir,Pa_u_indir,bin_edges_indir = resi[1]
        Ihyb,mean_hyb,std_hyb,Pa_u_hyb,bin_edges_hyb = resi[2]

        #axi.errorbar(bin_edges_dir[:-1],mean_dir,yerr=std_dir,fmt="o",color='blue')
        #axi.errorbar(bin_edges_indir[:-1],mean_indir,yerr=std_indir,fmt="o",color='red')
        #axi.errorbar(bin_edges_hyb[:-1],mean_hyb,yerr=std_hyb,fmt="o",color='green')

        axi.plot(bin_edges_dir[:-1],mean_dir,"o",color='blue')
        axi.plot(bin_edges_indir[:-1],mean_indir,"o",color='red')
        axi.plot(bin_edges_hyb[:-1],mean_hyb,"o",color='green')

        axi.set_xlabel('$U_f$',fontsize=18)
        axi.set_ylabel(r'$\langle N_{A} \rangle$',fontsize=18)

        print("**************************************************")
        print("Direct Mechanism: MI = {},\n alpha0 = {}, alpha1 = {}".format(
             Idir,data['dir'][i,-2],data['dir'][i,-1]))
        print("Indirect Mechanism: MI = {},\n alpha0 = {}, beta1 = {}".format(
             Iindir,data['indir'][i,-2],data['indir'][i,-1]))
        print("Hybrid Mechanism: MI = {},\n alpha0 = {}, alpha1 = {}, beta1 = {}".format(
             Ihyb,data['hyb'][i,-3],data['hyb'][i,-2],data['hyb'][i,-1]))


    fig.tight_layout()

    #figname = "./Figures/optimal_response_functions_{}_B0_{}.eps".format(plot_Nv_val,B0)
    #fig.savefig(figname,edgecolor='black')

    

    #--------------------------------------------------------------------------
    plt.show()
