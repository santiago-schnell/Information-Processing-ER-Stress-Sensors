import numpy as np
import matplotlib as mpl
mpl.use("TKAgg")
label_size = 16
mpl.rcParams['xtick.labelsize'] = label_size
mpl.rcParams['ytick.labelsize'] = label_size
import matplotlib.pyplot as plt
from scipy.integrate import quad
from scipy.special import gammaln
import mutual_information_2D_input_2isomers as mi2d
import glob
from joblib import Parallel, delayed
from plot_MI_optimization_results_2Dinput import calc_optimized_response_functions

########################################################################################
#---------------------------------------------------------------------------------------
def calcu_theta_c(theta,c0):
    return c0/theta - 1.
#---------------------------------------------------------------------------------------
def KIA(alpha,beta,gamma,u,c0):
    ''' Calculates equilibrium activation for sensor.
    '''
    c = c0/(1.+u)
    return gamma * (1. + alpha*u)/(1. + beta*c)
#---------------------------------------------------------------------------------------
def mu(N,alpha,beta,gamma,u,c0):
    ''' Calculates mean value for active sensors in the hybrid model. Setting alpha=0 gives
        mean value of indirect model, and setting beta=0 gives mean value of direct model.
    '''
    K = KIA(alpha,beta,gamma,u,c0)
    mu = N*K/(1.+K)

    return mu
#---------------------------------------------------------------------------------------
def pna_u_saddlepoint(n,N,alpha,beta,gamma,u,c0min,c0max):
    ''' Saddlepoint approximation for the conditional probability of activation for the 
        general (hybrid) model. Setting alpha=0 will give results for the indirect model.
    '''
    muMin = mu(N,alpha,beta,gamma,u,c0max)
    muMax = mu(N,alpha,beta,gamma,u,c0min)

    pna = 0.0
    if n>=muMin:
        if n <= muMax:

            dlnMu = np.log(muMax)-np.log(muMin)
            pna = 1./(n*dlnMu)

    return pna 
#---------------------------------------------------------------------------------------
def pna_t_saddlepoint(n,N,alpha,beta,gamma,UofT,t,c0min,c0max):
    ''' Saddlepoint approximation for the conditional probability of activation for the 
        general (hybrid) model. Setting alpha=0 will give results for the indirect model.
    '''
    muMin = mu(N,alpha,beta,gamma,UofT(t,c0max),c0max)
    muMax = mu(N,alpha,beta,gamma,UofT(t,c0min),c0min)
    pna = 0.0
    if n>=muMin:
        if n <= muMax:

            dlnMu = np.log(muMax)-np.log(muMin)
            pna = 1./(n*dlnMu)

    return pna 

#---------------------------------------------------------------------------------------
def mean_act_saddlepoint(u,N,alpha,beta,gamma,c0min,c0max):
    ''' Calculates the mean activation as a function of u for the saddle point
        approximation fo the conditional activation probability distribution.
    '''
    muMin = mu(N,alpha,beta,gamma,u,c0max)
    muMax = mu(N,alpha,beta,gamma,u,c0min)

    na_mean = (muMax-muMin)/np.log(muMax/muMin)

    return na_mean
#---------------------------------------------------------------------------------------
#---------------------------------------------------------------------------------------
if __name__=="__main__":

    ###################################
    # Set parameters
    '''
    gamma_dir = 2.334e-5
    alpha_dir = 2.303
    beta_dir = 0.

    gamma_ind = 1703.
    alpha_ind = 0.
    beta_ind = 9828.

    gamma_hyb = 2.678e-6
    alpha_hyb = 21.205
    beta_hyb = 5.881e-1

    N = 200
    na = range(N)

    c0min = 1000.
    c0max = 4770.
    '''
    # parameters for uf case point (8,0)
    tag = "Uf_8_0"
    gamma_dir = 1.00000000e-06
    alpha_dir = 4.42076592e+01
    beta_dir = 0.

    gamma_ind = 1066.8512919
    alpha_ind = 0.
    beta_ind = 14301.47507249

    gamma_hyb = 9.52573071e-04
    alpha_hyb = 1.34974001e+00
    beta_hyb = 4.88548901e+02

    N = 101
    na = range(N)

    c0min = 1000.
    c0max = 2000.
    ###################################
    # plot approximate heatmap
    urange = np.linspace(0.,65000.,200)

    vmin = 0.0
    vmax = 0.10
    cmap = 'viridis'

    U,NA = np.meshgrid(urange,na)
    pna_u_ind = lambda ui,nai: pna_u_saddlepoint(nai,N,0.,beta_ind,gamma_ind,ui,c0min,c0max)
    pna_u_hyb = lambda ui,nai: pna_u_saddlepoint(nai,N,alpha_hyb,beta_hyb,gamma_hyb,ui,c0min,c0max)
    pna_u_dir = lambda ui,nai: 0.#pna_u_saddlepoint(nai,N,alpha_dir,beta_dir,gamma_dir,ui,c0min,c0min+100.)

    PNA_U_Ind = np.zeros(U.shape)
    PNA_U_Hyb = np.zeros(U.shape)
    PNA_U_Dir = np.zeros(U.shape)
    for i in range(U.shape[0]):
        for j in range(U.shape[1]):
            PNA_U_Ind[i,j] = pna_u_ind(U[i,j],NA[i,j])
            PNA_U_Hyb[i,j] = pna_u_hyb(U[i,j],NA[i,j])
            PNA_U_Dir[i,j] = pna_u_dir(U[i,j],NA[i,j])

    figHM, axHM = plt.subplots(1,3,figsize=(12,4))

    #----- Plot Direct -----#
    pcDir = axHM[0].pcolormesh(U,NA,PNA_U_Dir,vmin=vmin,vmax=vmax,cmap=cmap)
    #cbarIND = figHM.colorbar(pcInd,ax=axHM[0])
    #cbarIND.set_label(r'$p(n_{{A}}|u)$',fontsize=16)

    mu_dir = mu(N,alpha_dir,beta_dir,gamma_dir,urange,c0max)
    color = plt.get_cmap(cmap)(1.0)
    axHM[0].plot(urange,mu_dir,linewidth=2,color=color)

    axHM[0].set_xlabel(r'$u$',fontsize=18)
    axHM[0].set_ylabel(r'$n_{{A}}$',fontsize=18)

    #----- Plot Indirect -----#
    pcInd = axHM[1].pcolormesh(U,NA,PNA_U_Ind,vmin=vmin,vmax=vmax,cmap=cmap)
    #cbarIND = figHM.colorbar(pcInd,ax=axHM[1])
    #cbarIND.set_label(r'$p(n_{{A}}|u)$',fontsize=16)

    axHM[1].set_xlabel(r'$u$',fontsize=18)
    #axHM[1].set_ylabel(r'$n_{{A}}$',fontsize=18)

    #----- Plot Hybrid ------#
    pcHyb = axHM[2].pcolormesh(U,NA,PNA_U_Hyb,vmin=vmin,vmax=vmax,cmap=cmap)
    #cbarHYB = figHM.colorbar(pcHyb,ax=axHM[1])
    #cbarHYB.set_label(r'$p(n_{{A}}|u)$',fontsize=16)

    axHM[2].set_xlabel(r'$u$',fontsize=18)
    #axHM[1].set_ylabel(r'$n_{{A}}$',fontsize=18)

    #----- Add Colorbar -----#

    figHM.tight_layout()

    figHM.subplots_adjust(right=0.8)
    cbar_ax = figHM.add_axes([0.85, 0.20, 0.03, 0.7])
    cbar = figHM.colorbar(pcHyb, cax=cbar_ax)
    cbar.set_label(r'$p(n_{{A}}|u)$',fontsize=16)


    ###################################
    # plot approximate pna_u for different dC0
    uval = 20000.
    #deltaC0 = np.logspace(2,4,3)
    deltaC0 = np.array([100.,500.,5000.])

    figdC0, axdC0 = plt.subplots(1,1)
    pna_u_c0 = lambda nai,c0mini,c0maxi: pna_u_saddlepoint(nai,N,0.,beta_ind,gamma_ind,uval,c0mini,c0maxi)
    for dC0i in deltaC0:
        cmaxi = c0min + dC0i
        pna_ui = [pna_u_c0(nai,c0min,cmaxi) for nai in na]
        
        axdC0.plot(na,pna_ui,linewidth=2,label=r'$\Delta C_{{0}}={}$'.format(dC0i))

    axdC0.legend()

    axdC0.set_xlabel(r'$n_{A}$',fontsize=18)
    axdC0.set_ylabel(r'$p(n_{A}|u)$',fontsize=18)

    figdC0.tight_layout()

    ###################################
    # plot approximate mean activation
    mean_ind = lambda u: mean_act_saddlepoint(u,N,alpha_ind,beta_ind,gamma_ind,c0min,c0max)
    mean_hyb = lambda u: mean_act_saddlepoint(u,N,alpha_hyb,beta_hyb,gamma_hyb,c0min,c0max)

    figMeanAct, axMeanAct = plt.subplots(1,1)
    axMeanAct.plot(urange,mean_ind(urange),linewidth=2,label=r'Indirect')
    axMeanAct.plot(urange,mean_hyb(urange),linewidth=2,label=r'Hybrid')

    axMeanAct.set_xlabel(r'$u$',fontsize=18)
    axMeanAct.set_ylabel(r'$\langle n_{A} \rangle_{sp}$',fontsize=18)
    axMeanAct.legend()

    figMeanAct.tight_layout()

    ########################################################################################################
    ########################################################################################################
    # theta=c

    ###################################
    # plot approximate heatmap
    trange = np.linspace(0.,4000.,20)

    vmin = 0.0
    vmax = 0.10

    T,NA = np.meshgrid(trange,na)
    pna_t_ind = lambda ti,nai: pna_t_saddlepoint(nai,N,0.,beta_ind,gamma_ind,calcu_theta_c,ti,c0min,c0max)
    pna_t_hyb = lambda ti,nai: pna_t_saddlepoint(nai,N,alpha_hyb,beta_hyb,gamma_hyb,calcu_theta_c,ti,c0min,c0max)

    PNA_C_Ind = np.zeros(T.shape)
    PNA_C_Hyb = np.zeros(T.shape)
    for i in range(T.shape[0]):
        for j in range(T.shape[1]):
            PNA_C_Ind[i,j] = pna_t_ind(T[i,j],NA[i,j])
            PNA_C_Hyb[i,j] = pna_t_hyb(T[i,j],NA[i,j])

    print(PNA_C_Ind)
    figHM_c, axHM_c = plt.subplots(1,2,figsize=(10,4))

    #----- Plot Indirect -----#
    pcInd_c = axHM_c[0].pcolormesh(T,NA,PNA_C_Ind,vmin=vmin,vmax=vmax)
    cbarIND_c = figHM_c.colorbar(pcInd_c,ax=axHM_c[0])
    cbarIND_c.set_label(r'$p(n_{{A}}|u)$',fontsize=16)

    axHM_c[0].set_xlabel(r'$u$',fontsize=18)
    axHM_c[0].set_ylabel(r'$n_{{A}}$',fontsize=18)

    #----- Plot Hybrid ------#
    pcHyb_c = axHM_c[1].pcolormesh(T,NA,PNA_C_Hyb,vmin=vmin,vmax=vmax)
    cbarHYB_c = figHM_c.colorbar(pcHyb_c,ax=axHM_c[1])
    cbarHYB_c.set_label(r'$p(n_{{A}}|u)$',fontsize=16)

    axHM_c[1].set_xlabel(r'$u$',fontsize=18)
    axHM_c[1].set_ylabel(r'$n_{{A}}$',fontsize=18)


    figHM_c.tight_layout()



    ###################################
    # Save figures to files
    save_bool = 0
    if save_bool:
        #figHM.savefig('./Figures/ApproxHeatMap_indirect'+tag+'.eps',edgecolor='black')
        figHM.savefig('./Figures/ApproxHeatMap_indirect'+tag+'.pdf')
        figdC0.savefig('./Figures/Pna_uSlices_deltaC0'+tag+'.eps',edgecolor='black')

    plt.show()
