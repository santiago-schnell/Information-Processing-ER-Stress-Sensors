import numpy as np
import matplotlib as mpl
mpl.use("TKAgg")
label_size = 16
mpl.rcParams['xtick.labelsize'] = label_size
mpl.rcParams['ytick.labelsize'] = label_size
import matplotlib.pyplot as plt
import mutual_information_2D_input_2isomers as mi2d
import glob
from joblib import Parallel, delayed
from plot_MI_optimization_results_2Dinput_THETA_Cf import calc_optimized_response_functions

###############################################################################################
#----------------------------------------------------------------------
#----------------------------------------------------------------------
if __name__=="__main__":

    ##### Import data from optimization of mechanisms #####
    mechnames = ["dir","indir","hyb"]
    tag = "2019_03_12-131831"	# B0min=1.0e3, Umin=1.0e3, N_I=100, Nu,Nb,nbins=100
    #tag = "2019_03_13-110856"	# B0min=1.0e3, Umin=1.0e3, N_I=50, Nu,Nb,nbins=100
    #tag = "2019_03_02-164824"	# B0min=1.0e3, Umin=1.0e3, N_I=200, Nu,Nb,nbins=100
    #tag = "2019_03_17-164437"	# B0min=1.0e3, Umin=1.0e2, N_I=100, Nu,Nb,nbins=100 - must change Xmin and Ymin
    #tag = "2019_03_19-131346"	# B0min=1.0e3, Umin=1.0e4, N_I=100, Nu,Nb,nbins=100 - must change Xmin and Ymin

    basedir = "./OptData/THETA_Cf/"+tag+"/"

    filenames = [basedir+mechname+"_opt_results.npy" for mechname in mechnames]
    datasets = [np.load(filename) for filename in filenames]
    data = dict(zip(mechnames,datasets))
    #for key in data:
    #    print(key)
    #    print(data[key])
    #--------------------------------------------------------------------------
    ##### Parse data for plotting results ######

    # X = Cf
    Xmin_plot_val = 1.0e3 #1.0e2
    Xmax_factors = np.logspace(np.log10(2.0),2.,10) #[2.,10.,100.]

    # Y = U0
    Ymin_plot_val = 1.0e3
    Ymax_factors = np.logspace(np.log10(2.0),2.,10) #[2.,10.,100.]


    Xfact,Yfact = np.meshgrid(Xmax_factors,Ymax_factors)

    plot_inds = [[] for i in Xmax_factors]
    for i in range(data['dir'].shape[0]):
        Xmin = data['dir'][i,0]
        Xmax = data['dir'][i,1]
        Ymin = data['dir'][i,2]
        Ymax = data['dir'][i,3]
        Xmax_factor = Xmax/Xmin
        Ymax_factor = Ymax/Ymin
        if Xmin==Xmin_plot_val:
            if Ymin==Ymin_plot_val:
                for j,Xj in enumerate(Xmax_factors):
                    if int(Xmax_factor)==int(Xj):
                        for k,Yk in enumerate(Ymax_factors):
                            if int(Ymax_factor)==int(Yk):
                                plot_inds[j].append(i)

    #plot_inds = [[0]]
    ##### Calculate information for results to be plotted #####
    def parfunc(ind):
        return calc_optimized_response_functions(data,ind)

    results = []	# results[i][j] returns the ith u range and the jth B0 range
    for plot_indsj in plot_inds:	# all B0 ranges for given u range
        n_jobs = min(len(plot_indsj),9)
        results.append(Parallel(n_jobs=n_jobs)(map(delayed(parfunc),plot_indsj)))
    
    Idir = np.zeros(Xfact.shape)
    Iindir = np.zeros(Xfact.shape)
    Ihyb = np.zeros(Xfact.shape)
    for i,resi in enumerate(results):
        for j,resij in enumerate(resi):
            Idirij,mean_dir,std_dir,Pa_theta_dir,bin_edges_dir = resij[0]
            Iindirij,mean_indir,std_indir,Pa_theta_indir,bin_edges_indir = resij[1]
            Ihybij,mean_hyb,std_hyb,Pa_theta_hyb,bin_edges_hyb = resij[2]

            Idir[j,i] = Idirij		# indexes reversed to correspond with meshgrid indexing
            Iindir[j,i] = Iindirij
            Ihyb[j,i] = Ihybij

    #DeltaI = Idir - Iindir
    DeltaI = Ihyb - Iindir
    #print(DeltaI)
    #print(Idir)
    #print(Iindir)

    minI = np.min([np.min(i) for i in [Idir,Iindir,Ihyb]])
    maxI = np.max([np.max(i) for i in [Idir,Iindir,Ihyb]])

    ##### Plot delta MI heat map #####

    cmap = 'plasma'#'viridis'#'cividis'
    '''
    figDel,axDel = plt.subplots(1,1)
    figDir,axDir = plt.subplots(1,1)
    figInd,axInd = plt.subplots(1,1)
    figHyb,axHyb = plt.subplots(1,1)

    pcDel = axDel.pcolormesh(Xfact,Yfact,DeltaI,cmap=cmap)
    pcDir = axDir.pcolormesh(Xfact,Yfact,Idir,cmap=cmap,vmin=minI,vmax=maxI)
    pcInd = axInd.pcolormesh(Xfact,Yfact,Iindir,cmap=cmap,vmin=minI,vmax=maxI)
    pcHyb = axHyb.pcolormesh(Xfact,Yfact,Ihyb,cmap=cmap,vmin=minI,vmax=maxI)

    for axi in [axDel,axDir,axInd,axHyb]:
        axi.set_xscale('log')
        axi.set_yscale('log')
        axi.set_xlabel(r'$C_{F,\max}/C_{F,\min}$',fontsize=18)
        axi.set_ylabel(r'$U_{T,\max}/U_{T,\min}$',fontsize=18)

    cbarDel = figDel.colorbar(pcDel)
    cbarDel.set_label(r'$I_{dir} - I_{indir}$ (bits)',fontsize=16)
    cbarDir = figDir.colorbar(pcDir)
    cbarDir.set_label(r'$I_{dir}$ (bits)',fontsize=16)
    cbarInd = figInd.colorbar(pcInd)
    cbarInd.set_label(r'$I_{indir}$ (bits)',fontsize=16)
    cbarHyb = figHyb.colorbar(pcHyb)
    cbarHyb.set_label(r'$I_{hyb}$ (bits)',fontsize=16)

    figDel.tight_layout()
    figDir.tight_layout()
    figInd.tight_layout()
    figHyb.tight_layout()
    '''
    ### Plot all on one figure ###
    figDel,axDel = plt.subplots(1,1)
    figInfo, axInfo = plt.subplots(1,3,figsize=(12,4))
    axDir = axInfo[0]
    axInd = axInfo[1]
    axHyb = axInfo[2]
    figs = [figDel,figInfo]

    pcDel = axDel.pcolormesh(Xfact,Yfact,DeltaI,cmap=cmap)
    pcDir = axDir.pcolormesh(Xfact,Yfact,Idir,cmap=cmap,vmin=minI,vmax=maxI)
    pcInd = axInd.pcolormesh(Xfact,Yfact,Iindir,cmap=cmap,vmin=minI,vmax=maxI)
    pcHyb = axHyb.pcolormesh(Xfact,Yfact,Ihyb,cmap=cmap,vmin=minI,vmax=maxI)

    for axi in [axDel,axDir,axInd,axHyb]:
        axi.set_xscale('log')
        axi.set_yscale('log')
        axi.set_aspect('equal',adjustable='box')
        axi.set_xlabel(r'$c_{\max}/c_{\min}$',fontsize=18)

    #axDel.set_ylabel(r'$C_{0,\max}/C_{0,\min}$',fontsize=18)
    #axInfo[0].set_ylabel(r'$C_{0,\max}/C_{0,\min}$',fontsize=18)
    axDel.set_ylabel(r'$U_{0,\max}/U_{0,\min}$',fontsize=18)
    axInfo[0].set_ylabel(r'$U_{0,\max}/U_{0,\min}$',fontsize=18)

    for figi in figs:
        figi.tight_layout()

    figInfo.subplots_adjust(right=0.8)
    cbar_ax = figInfo.add_axes([0.85, 0.20, 0.03, 0.7])
    cbar = figInfo.colorbar(pcHyb, cax=cbar_ax)
    cbar.set_label(r'$I$ (bits)',fontsize=16)

    #########################################################################
    ##### Plot Transfer Functions #####

    ##### Print optimal values for specific point to plot response function #####
    ui = 8	#4
    b0i = 0	#4
    ind = plot_inds[ui][b0i]
    Xmin = data['dir'][ind,0]
    Xmax = data['dir'][ind,1]
    Ymin = data['dir'][ind,2]
    Ymax = data['dir'][ind,3]
    N_I = int(data['dir'][ind,4])
    Nu = int(data['dir'][ind,5])
    Nb = int(data['dir'][ind,6])
    nbins = int(data['dir'][ind,7])
    Kd = 1.0
    
    alpha0_dir = data['dir'][ind,-2] 
    alpha1_dir = data['dir'][ind,-1]

    alpha0_indir = data['indir'][ind,-2] 
    beta1_indir = data['indir'][ind,-1]

    alpha0_hyb = data['hyb'][ind,-3] 
    alpha1_hyb = data['hyb'][ind,-2] 
    beta1_hyb = data['hyb'][ind,-1] 

    print("****************************************")
    print("Cfmin,Cfmax = ({0},{1})".format(data['dir'][ind,0],data['dir'][ind,1]))
    print("U0min,U0max = ({0},{1})".format(data['dir'][ind,2],data['dir'][ind,3]))
    print(data['dir'][ind,-2:])
    print(data['indir'][ind,-2:])
    print(data['hyb'][ind,-3:])
    print("****************************************")


    # Construct input distributions

    THETA = np.zeros((Nu,Nb))
    U0 = np.zeros(THETA.shape)
    B0 = np.zeros(THETA.shape)
    
    Xvals = np.linspace(Xmin,Xmax,Nu)
    Yvals = np.linspace(Ymin,Ymax,Nb)
    zfunc = lambda x,y: mi2d.B0eq_from_b_U0(x,y,Kd)
    TH,U0,B0 = mi2d.generate_input_distributions(Xvals,Yvals,zfunc)

    inputs = [U0,B0,TH]

    # Define Equilibrium constant wrapper functions (picklable for joblib)
    def KaIA_DIR(U0,B0):
        return mi2d.KaIA_dir(U0,B0,Kd,alpha0_dir,alpha1_dir)

    def KaIA_INDIR(U0,B0):
        return mi2d.KaIA_indir(U0,B0,Kd,alpha0_indir,beta1_indir)

    def KaIA_HYB(U0,B0):
        return mi2d.KaIA_hyb(U0,B0,Kd,alpha0_hyb,alpha1_hyb,beta1_hyb)

    return_Pa_u = True

    def parallel_work(arg):
        return mi2d.calc_2isomer_mutual_information_general(N_I,inputs,arg[0],Kd,nbins=nbins,return_extras=return_Pa_u)

    input_args = [(KaIA_DIR,),(KaIA_INDIR,),(KaIA_HYB,)]

    results = Parallel(n_jobs=3)(delayed(parallel_work)(arg) for arg in input_args)

    mi_dir,extras_dir = results[0]
    mi_indir, extras_indir = results[1]
    mi_hyb, extras_hyb = results[2]

    print("******************************************")
    print("Nu = {}, Nb = {}, nbins = {}".format(Nu,Nb,nbins))
    print("Mutual Information:")
    print(mi_dir)
    print(mi_indir)
    print(mi_hyb)
    print("******************************************")


    # Plot activation vs free unfolded protein

    vmax =0.10# np.max([np.max(Pa_ui) for Pa_ui in [extras_dir[0],extras_indir[0],extras_hyb[0]]])
    vminmax = (0.,vmax)

    #xlabel = "Free Chaperone"
    xlabel = r"$c$"
    '''
    figHM_dir = mi2d.plot_Pa_u_heatmap(N_I,extras_dir[0],extras_dir[1],vminmax=vminmax,xlabel=xlabel)
    figHM_indir = mi2d.plot_Pa_u_heatmap(N_I,extras_indir[0],extras_indir[1],vminmax=vminmax,xlabel=xlabel)
    figHM_hyb = mi2d.plot_Pa_u_heatmap(N_I,extras_hyb[0],extras_hyb[1],vminmax=vminmax,xlabel=xlabel)

    figHM_dir.tight_layout()
    figHM_indir.tight_layout()
    figHM_hyb.tight_layout()
    '''

    ### Plot cond prob vs activation on same figure
    ylabel=None
    figHM, axHM = plt.subplots(1,3,figsize=(12,4))
    pcs = []
    for axi,exti in zip(axHM,[extras_dir,extras_indir,extras_hyb]):
        pcs.append(mi2d.plot_Pa_u_heatmap(N_I,exti[0],exti[1],vminmax=vminmax,xlabel=xlabel,ylabel=ylabel,ax=axi))

    axHM[0].set_ylabel(r'$n_{A}$',fontsize=18)

    figHM.tight_layout()

    figHM.subplots_adjust(right=0.8)
    cbar_axHM = figHM.add_axes([0.85, 0.20, 0.03, 0.7])
    cbarHM = figHM.colorbar(pcs[-1], cax=cbar_axHM)
    cbarHM.set_label(r'$p(n_{A}|c)$',fontsize=16)

    # Plot mean values and variance vs free unfolded protein
    Pa_t_dir = extras_dir[0]
    bin_edges_dir = extras_dir[1][:-1]
    
    Pa_t_indir = extras_indir[0]
    bin_edges_indir = extras_indir[1][:-1]

    Pa_t_hyb = extras_hyb[0]
    bin_edges_hyb = extras_hyb[1][:-1]

    mean_dir,std_dir = mi2d.calc_mean_std_Na_vs_uf(N_I,Pa_t_dir,bin_edges_dir)
    mean_indir,std_indir = mi2d.calc_mean_std_Na_vs_uf(N_I,Pa_t_indir,bin_edges_indir)
    mean_hyb,std_hyb = mi2d.calc_mean_std_Na_vs_uf(N_I,Pa_t_hyb,bin_edges_hyb)

    figMeanVar,axMeanVar = plt.subplots(1,2,figsize=(10,4))

    line_dir = "b-"
    line_indir = "r--"
    line_hyb = "g-."


    # Dont plot first or last bin

    axMeanVar[0].plot(bin_edges_dir[1:-1],mean_dir[1:-1],line_dir,linewidth=2,label="unfolded protein-mediated")
    axMeanVar[0].plot(bin_edges_indir[1:-1],mean_indir[1:-1],line_indir,linewidth=2,label="chaperone-mediated")
    axMeanVar[0].plot(bin_edges_hyb[1:-1],mean_hyb[1:-1],line_hyb,linewidth=2,label="hybrid")

    axMeanVar[1].plot(bin_edges_dir[1:-1],std_dir[1:-1],line_dir,linewidth=2,label="unfolded protein-mediated")
    axMeanVar[1].plot(bin_edges_indir[1:-1],std_indir[1:-1],line_indir,linewidth=2,label="chaperone-mediated")
    axMeanVar[1].plot(bin_edges_hyb[1:-1],std_hyb[1:-1],line_hyb,linewidth=2,label="hybrid")

    '''
    axMeanVar[0].plot(bin_edges_dir,mean_dir,linewidth=2,label="direct")
    axMeanVar[0].plot(bin_edges_indir,mean_indir,linewidth=2,label="indirect")
    axMeanVar[0].plot(bin_edges_hyb,mean_hyb,linewidth=2,label="hybrid")

    axMeanVar[1].plot(bin_edges_dir,std_dir,linewidth=2,label="direct")
    axMeanVar[1].plot(bin_edges_indir,std_indir,linewidth=2,label="indirect")
    axMeanVar[1].plot(bin_edges_hyb,std_hyb,linewidth=2,label="hybrid")
    '''

    axMeanVar[0].set_xlabel(r'$c$',fontsize=18)
    axMeanVar[0].set_ylabel(r'$\langle n_{A} \rangle$',fontsize=18)
    axMeanVar[0].legend()
    axMeanVar[1].set_xlabel(r'$c$',fontsize=18)
    axMeanVar[1].set_ylabel(r'$\sigma_{A}$',fontsize=18)

    figMeanVar.tight_layout()

    #############################################################################################################
    savefigures = 0
    if savefigures:
        figDel.savefig("./Figures/heatMapDel_Cf.eps")#,edgecolor='black')
        #figDir.savefig("./Figures/heatMapDir_Cf.eps")#,edgecolor='black')
        #figInd.savefig("./Figures/heatMapInd_Cf.eps")#,edgecolor='black')
        #figHyb.savefig("./Figures/heatMapHyb_Cf.eps")#,edgecolor='black')

        # If single figure w/ subplots
        figInfo.savefig("./Figures/heatMapCombinedCf_"+tag+".eps")

    saveActFigs = 0
    if saveActFigs:
        #figHM_dir.savefig("./Figures/activationHeatMapDirect_Cf_{0}_{1}.eps".format(ui,b0i))#,edgecolor="black")
        #figHM_indir.savefig("./Figures/activationHeatMapIndirect_Cf_{0}_{1}.eps".format(ui,b0i))#,edgecolor="black")
        #figHM_hyb.savefig("./Figures/activationHeatMapHybrid_Cf_{0}_{1}.eps".format(ui,b0i))#,edgecolor="black")
        figMeanVar.savefig("./Figures/activationMeanVar_Cf_{0}_{1}.eps".format(ui,b0i))#,edgecolor="black")

        # If single figure w/ subplots
        figHM.savefig("./Figures/activationHeatMapCombinedCf_"+tag+"_{0}_{1}.eps".format(ui,b0i))#
    plt.show()
