import numpy as np
import argparse
#--------------------------------------------------------------------------------------------
def print_file_data(filename,data_index):
    print("*******************************************************")
    print("Data from index {} of file ".format(data_index) + filename)
    print("*******************************************************")
    data = np.load(filename)
    datai = data[data_index]
    data_headers = ["Xmin","Xmax","Ymin","Ymax","N_I","N_x","N_y","N_bins","Input type","Optimal Parameters"]
    for di,hi in zip(datai[0:9],data_headers[0:9]):
        print(hi+": {}".format(di))

    print(data_headers[-1] + ": ")
    print(datai[9:])
    print("*******************************************************")
#--------------------------------------------------------------------------------------------
if __name__=="__main__":

    parser = argparse.ArgumentParser(description = "Description for my parser")
    parser.add_argument("-f", "--filename", help = "path to numpy data file", required = True, default = "")
    parser.add_argument("-i", "--index", help = "index of data in file", required = False, default = 0)

    args = parser.parse_args()
    print_file_data(args.filename,int(args.index))
