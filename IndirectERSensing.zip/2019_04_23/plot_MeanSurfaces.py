import numpy as np
#import mayavi.mlab as mlab
import matplotlib.pyplot as plt
from matplotlib import cm
import mpl_toolkits.mplot3d as Axes3D
import mutual_information_2D_input_2isomers as mi2d
#--------------------------------------------------
def mu_hyb(U0,B0,Kd,gamma,alpha,beta,N):
    ''' This calculates mu for u0, and b0.
    '''
    Kia = mi2d.KaIA_hyb(U0,B0,Kd,gamma,alpha,beta)
    return N * Kia / (1. + Kia)
#--------------------------------------------------
def expect_na_hyb(U0,B0min,B0max,Kd,gamma,alpha,beta,N):
    ''' This calculates <Na> for u0, and range of b0.
    '''
    mu_min = mu_hyb(U0,B0max,Kd,gamma,alpha,beta,N)
    mu_max = mu_hyb(U0,B0min,Kd,gamma,alpha,beta,N)
    #if mu_min==mu_max:
    #    return mu_min
 
    return (mu_max - mu_min)/(np.log(mu_max)-np.log(mu_min))
#--------------------------------------------------
#--------------------------------------------------
if __name__=="__main__":

    # Set Parameters
    # X=Uf, Y=C0
    #params_dir = [1.885e-5, 2.1e1, 0.0]
    #params_indir = [6139.70, 0.0,8371.0]
    #params_hyb = [3.53442424e-05, 2.28528595e+01, 1.74400517e+00]
    #N = 50
  
    # parameters for uf case at point (8,0)
    params_dir = [1.00000000e-06, 4.42076592e+01, 0.0]
    params_indir = [1066.8512919,0.0, 14301.47507249]
    params_hyb = [9.52573071e-04, 1.34974001e+00, 4.88548901e+02]
    
    N = 100
    Kd = 1.

    xr = np.linspace(1000.,65000.,200)
    yr = np.linspace(1000.,2000.,100)

    def na(x,y,params):
        # transform (x,y) -> (U0,C0)
        U0 = mi2d.U0eq(x,y,Kd)
        C0 = y#mi2d.B0eq(x,U0,Kd)
        return mu_hyb(U0,C0,Kd,params[0],params[1],params[2],N)

    X, Y = np.meshgrid(xr,yr)

    NA_dir = na(X,Y,params_dir)
    NA_indir = na(X,Y,params_indir)
    NA_hyb = na(X,Y,params_hyb)

    color_dir = "blue"
    color_indir = "red"
    color_hyb = "green"
    '''
    fig = plt.figure(figsize=(10,4))
    ax = fig.add_subplot(121, projection='3d')

    ax.plot_surface(X,Y,NA_dir,color=color_dir)
    ax.plot_surface(X,Y,NA_indir,color=color_indir)
    ax.plot_surface(X,Y,NA_hyb,color=color_hyb)

    ax.set_xlabel(r'$u$',fontsize=18)
    ax.set_ylabel(r'$C_{0}$',fontsize=18)
    ax.set_zlabel(r'$\langle n_A\rangle$',fontsize=18)

    ax.locator_params(nbins=3)
    ax.view_init(elev=15.,azim=-120.) 
    ax.xaxis.labelpad=20
    ax.yaxis.labelpad=20
    ax.zaxis.set_rotate_label(False)
    ax.zaxis.label.set_rotation(90)

    ax.grid(False)
    #ax.xaxis.pane.set_edgecolor('black')
    #ax.yaxis.pane.set_edgecolor('black')
    #ax.zaxis.pane.set_edgecolor('black')
    ax.xaxis.pane.fill = False
    ax.yaxis.pane.fill = False
    ax.zaxis.pane.fill = False
    ax.set_frame_on(False)

    # Plot projection
    ax2 = fig.add_subplot(122)
    ax2.plot(xr,na(xr,yr[0],params_dir),linewidth=3,color=color_dir)
    ax2.contourf(X,NA_indir,Y,colors=color_indir,alpha=0.6,antialiased=True)
    ax2.contourf(X,NA_hyb,Y,colors=color_hyb,alpha=0.6,antialiased=True)

    #ax2.set_xlabel(r'$\theta$',fontsize=18)
    ax2.set_xlabel(r'$u$',fontsize=18)
    ax2.set_ylabel(r'$\langle n_A\rangle$',fontsize=18)

    fig.tight_layout()
    '''
    #------------------------------------------------------------------------------------
    #------------------------------------------------------------------------------------

    figP = plt.figure(figsize=(12,5))
    axP = figP.add_subplot(121, projection='3d')

    #axP.plot_surface(X,Y,NA_dir,color=color_dir,rstride=8, cstride=8, alpha=0.5)
    #axP.plot_surface(X,Y,NA_indir,color=color_indir,rstride=8, cstride=8, alpha=0.5)
    axP.plot_surface(X,Y,NA_hyb,color=color_hyb,rstride=8, cstride=8, alpha=0.5)
    axP.plot_surface(X,Y,np.ones(NA_hyb.shape),color='grey',rstride=8, cstride=8, alpha=0.5)

    x_offset = min(xr) - 0.1*min(xr)
    y_offset = max(yr) + 0.1*max(yr)

    #cset = axP.plot(xr, y_offset*np.ones(xr.shape), na(xr,yr[0],params_dir), zdir='z',color=color_dir)
    #cset = axP.contourf(X, Y, NA_indir, zdir='y', offset=y_offset,levels=[min(xr),max(xr)],colors=[color_indir], alpha=0.6, antialiased=True)
    cset = axP.contourf(X, Y, NA_hyb, zdir='y', offset=y_offset,levels=[min(xr),max(xr)],colors=[color_hyb], alpha=0.6, antialiased=True)

    #axP.set_xlim(x_offset, max(xr)+0.1*max(xr))
    axP.set_xlim(0., max(xr)+0.1*max(xr))
    axP.set_ylim(min(xr) - 0.1*min(xr), y_offset)

    axP.grid(False)
    axP.set_frame_on(False)
    #axP.xaxis.pane.set_edgecolor('black')
    #axP.yaxis.pane.set_edgecolor('black')
    #axP.zaxis.pane.set_edgecolor('black')

    axP.set_xlabel(r'$u$',fontsize=18)
    axP.set_ylabel(r'$C_{0}$',fontsize=18)
    axP.set_zlabel(r'$\langle n_A\rangle$',fontsize=18)

    axP.locator_params(nbins=3)
    axP.xaxis.labelpad=20
    axP.yaxis.labelpad=20
    axP.yaxis.set_rotate_label(False)
    axP.zaxis.set_rotate_label(False)
    axP.zaxis.label.set_rotation(90)

    # Plot projection
    axP2 = figP.add_subplot(122)
    axP2.plot(xr,na(xr,yr[0],params_dir),linewidth=3,color=color_dir)
    axP2.contourf(X,NA_indir,Y,colors=color_indir,alpha=0.6,antialiased=True)
    axP2.contourf(X,NA_hyb,Y,colors=color_hyb,alpha=0.6,antialiased=True)

    #axP2.set_xlabel(r'$\theta$',fontsize=18)
    axP2.set_xlabel(r'$u$',fontsize=18)
    axP2.set_ylabel(r'$\langle n_A\rangle$',fontsize=18)

    axP2.ticklabel_format(axis='x',style='sci',scilimits=(0,0),useMathText=True)

    figP.tight_layout()
    figP.subplots_adjust(wspace=0.3)

    '''
    #------------------------------------------------------------------------------------
    #------------------------------------------------------------------------------------
    # Set Parameters
    # X=Cf, Y=C0
    #params_dir = [5.81564179e-04, 1.00000000e+04, 0.0]
    #params_indir = [5.17618651e+04, 0.0, 2.29307417e+00]
    #params_hyb = [5.17618651e+04, 2.37344217e+00, 2.65389375e+00]

    # params for cf case at (x,y)=(8,0)
    params_dir = [8.74116490e-04, 1.55568619e+04, 0.0]
    params_indir = [1.00376069e+06, 0.0, 4.43615950e+01]
    params_hyb = [25725.11030426, 592.00370803, 39.96516102]

    N = 100
    Kd = 1.

    xr = np.linspace(1000.,64747.,200)
    yr = np.linspace(1000.,2000.,100)

    def na_cfc0(x,y,params):
        # transform (x,y) -> (U0,C0)
        U0 = mi2d.U0eq_from_b_B0(x,y,Kd)
        C0 = y
        return mu_hyb(U0,C0,Kd,params[0],params[1],params[2],N)

    X, Y = np.meshgrid(xr,yr)

    NA_dir = na_cfc0(X,Y,params_dir)
    NA_indir = na_cfc0(X,Y,params_indir)
    NA_hyb = na_cfc0(X,Y,params_hyb)

    fig_cfc0 = plt.figure(figsize=(10,4))
    ax_cfc0 = fig_cfc0.add_subplot(121, projection='3d')

    ax_cfc0.plot_surface(X,Y,NA_dir,color=color_dir)
    ax_cfc0.plot_surface(X,Y,NA_indir,color=color_indir)
    ax_cfc0.plot_surface(X,Y,NA_hyb,color=color_hyb)

    ax_cfc0.set_xlabel(r'$c$',fontsize=18)
    ax_cfc0.set_ylabel(r'$C_{0}$',fontsize=18)
    ax_cfc0.set_zlabel(r'$\langle n_A\rangle$',fontsize=18)

    ax_cfc0.locator_params(nbins=3)
    ax_cfc0.view_init(elev=15.,azim=-120.)
    ax_cfc0.xaxis.labelpad=20
    ax_cfc0.yaxis.labelpad=20
    ax_cfc0.zaxis.set_rotate_label(False)
    ax_cfc0.zaxis.label.set_rotation(90)

    ax_cfc0.grid(False)
    #ax_cfc0.bbox
    #ax_cfc0.xaxis.pane.set_edgecolor('black')
    #ax_cfc0.yaxis.pane.set_edgecolor('black')
    #ax_cfc0.zaxis.pane.set_edgecolor('black')
    ax_cfc0.xaxis.pane.fill = False
    ax_cfc0.yaxis.pane.fill = False
    ax_cfc0.zaxis.pane.fill = False
    ax_cfc0.set_frame_on(False)

    ax2_cfc0 = fig_cfc0.add_subplot(122)
    ax2_cfc0.plot(xr,na_cfc0(xr,yr[0],params_indir),linewidth=3,color=color_indir)
    ax2_cfc0.contourf(X,NA_dir,Y,colors=color_dir,alpha=0.6,antialiased=True)
    ax2_cfc0.contourf(X,NA_hyb,Y,colors=color_hyb,alpha=0.6,antialiased=True)

    #ax2_cfc0.set_xlabel(r'$\theta$',fontsize=18)
    ax2_cfc0.set_xlabel(r'$c$',fontsize=18)
    ax2_cfc0.set_ylabel(r'$\langle n_A\rangle$',fontsize=18)

    fig_cfc0.tight_layout()

    '''
    #------------------------------------------------------------------------------------
    #------------------------------------------------------------------------------------
    # Set Parameters
    # X=Cf, Y=U0
    #params_dir = [5.81564179e-04, 1.00000000e+04, 0.0]
    #params_indir = [5.17618651e+04, 0.0, 2.29307417e+00]
    #params_hyb = [5.17618651e+04, 2.37344217e+00, 2.65389375e+00]

    # params for cf case at (x,y)=(8,0)
    params_dir = [8.74116490e-04, 1.55568619e+04, 0.0]
    params_indir = [1.00376069e+06, 0.0, 4.43615950e+01]
    params_hyb = [25725.11030426, 592.00370803, 39.96516102]

    N = 100
    Kd = 1.

    xr = np.linspace(1000.,64747.,200)
    yr = np.linspace(1000.,2000.,100)

    def na_cfu0(x,y,params):
        # transform (x,y) -> (U0,C0)
        U0 = y#mi2d.U0eq(x,y,Kd)
        C0 = mi2d.B0eq_from_b_U0(x,U0,Kd)
        return mu_hyb(U0,C0,Kd,params[0],params[1],params[2],N)

    X, Y = np.meshgrid(xr,yr)

    NA_dir = na_cfu0(X,Y,params_dir)
    NA_indir = na_cfu0(X,Y,params_indir)
    NA_hyb = na_cfu0(X,Y,params_hyb)

    '''
    fig_cfu0 = plt.figure(figsize=(10,4))
    ax_cfu0 = fig_cfu0.add_subplot(121, projection='3d')

    ax_cfu0.plot_surface(X,Y,NA_dir,color=color_dir)
    ax_cfu0.plot_surface(X,Y,NA_indir,color=color_indir)
    ax_cfu0.plot_surface(X,Y,NA_hyb,color=color_hyb)

    ax_cfu0.set_xlabel(r'$c$',fontsize=18)
    ax_cfu0.set_ylabel(r'$U_{0}$',fontsize=18)
    ax_cfu0.set_zlabel(r'$\langle n_A\rangle$',fontsize=18)

    ax_cfu0.locator_params(nbins=3)
    ax_cfu0.view_init(elev=15.,azim=-120.)
    ax_cfu0.xaxis.labelpad=20
    ax_cfu0.yaxis.labelpad=20
    ax_cfu0.zaxis.set_rotate_label(False)
    ax_cfu0.zaxis.label.set_rotation(90)

    ax_cfu0.grid(False)
    #ax_cfu0.bbox
    #ax_cfu0.xaxis.pane.set_edgecolor('black')
    #ax_cfu0.yaxis.pane.set_edgecolor('black')
    #ax_cfu0.zaxis.pane.set_edgecolor('black')
    ax_cfu0.xaxis.pane.fill = False
    ax_cfu0.yaxis.pane.fill = False
    ax_cfu0.zaxis.pane.fill = False
    ax_cfu0.set_frame_on(False)

    ax2_cfu0 = fig_cfu0.add_subplot(122)
    ax2_cfu0.plot(xr,na_cfu0(xr,yr[0],params_indir),linewidth=3,color=color_indir)
    ax2_cfu0.contourf(X,NA_dir,Y,colors=color_dir,alpha=0.6,antialiased=True)
    ax2_cfu0.contourf(X,NA_hyb,Y,colors=color_hyb,alpha=0.6,antialiased=True)

    #ax2_cfu0.set_xlabel(r'$\theta$',fontsize=18)
    ax2_cfu0.set_xlabel(r'$c$',fontsize=18)
    ax2_cfu0.set_ylabel(r'$\langle n_A\rangle$',fontsize=18)

    fig_cfu0.tight_layout()
    '''
    #------------------------------------------------------------------------------------
    #------------------------------------------------------------------------------------

    figPC = plt.figure(figsize=(12,5))
    axPC = figPC.add_subplot(121, projection='3d')

    #axP.plot_surface(X,Y,NA_dir,color=color_dir,rstride=8, cstride=8, alpha=0.5)
    #axP.plot_surface(X,Y,NA_indir,color=color_indir,rstride=8, cstride=8, alpha=0.5)
    axPC.plot_surface(X,Y,NA_hyb,color=color_hyb,rstride=8, cstride=8, alpha=0.5)
    axPC.plot_surface(X,Y,np.ones(NA_hyb.shape),color='grey',rstride=8, cstride=8, alpha=0.5)

    x_offset = min(xr) - 0.1*min(xr)
    y_offset = max(yr) + 0.1*max(yr)

    #cset = axPC.plot(xr, y_offset*np.ones(xr.shape), na(xr,yr[0],params_dir), zdir='z',color=color_dir)
    #cset = axPC.contourf(X, Y, NA_indir, zdir='y', offset=y_offset,levels=[min(xr),max(xr)],colors=[color_indir], alpha=0.6, antialiased=True)
    cset = axPC.contourf(X, Y, NA_hyb, zdir='y', offset=y_offset,levels=[min(xr),max(xr)],colors=[color_hyb], alpha=0.6, antialiased=True)

    #axPC.set_xlim(x_offset, max(xr)+0.1*max(xr))
    axPC.set_xlim(0., max(xr)+0.1*max(xr))
    axPC.set_ylim(min(xr) - 0.1*min(xr), y_offset)

    axPC.grid(False)
    axPC.set_frame_on(False)
    #axPC.xaxis.pane.set_edgecolor('black')
    #axPC.yaxis.pane.set_edgecolor('black')
    #axPC.zaxis.pane.set_edgecolor('black')

    axPC.set_xlabel(r'$c$',fontsize=18)
    axPC.set_ylabel(r'$U_{0}$',fontsize=18)
    axPC.set_zlabel(r'$\langle n_A\rangle$',fontsize=18)

    axPC.locator_params(nbins=3)
    axPC.xaxis.labelpad=20
    axPC.yaxis.labelpad=20
    axPC.yaxis.set_rotate_label(False)
    axPC.zaxis.set_rotate_label(False)
    axPC.zaxis.label.set_rotation(90)

    # Plot projection
    axPC2 = figPC.add_subplot(122)
    axPC2.plot(xr,na_cfu0(xr,yr[0],params_indir),linewidth=3,color=color_indir)
    axPC2.contourf(X,NA_dir,Y,colors=color_dir,alpha=0.6,antialiased=True)
    axPC2.contourf(X,NA_hyb,Y,colors=color_hyb,alpha=0.6,antialiased=True)

    #axPC2.set_xlabel(r'$\theta$',fontsize=18)
    axPC2.set_xlabel(r'$c$',fontsize=18)
    axPC2.set_ylabel(r'$\langle n_A\rangle$',fontsize=18)

    axPC2.ticklabel_format(axis='x',style='sci',scilimits=(0,0),useMathText=True)

    figPC.tight_layout()
    figPC.subplots_adjust(wspace=0.3)

    #-------------------------------------------------------------------------------------
    # Plot <nA> vs U
    figNaU, axNaU = plt.subplots(1,1)
    params = [9.52573071e-04, 1.34974001e+00, 4.88548901e+02]
    #params = [9.52573071e1, 1.0e-3, 4.88548901e+02]
    urange = np.linspace(0,6e4,400)
    C0min = 1e3
    gamma, alpha, beta = params
    C0max = np.linspace(1.1e3,10.0e3,10)
    for c0maxi in C0max:
        calc_na = lambda u: expect_na_hyb(u,C0min,c0maxi,Kd,gamma,alpha,beta,N)
        nA = calc_na(urange)
        axNaU.plot(urange,nA,linewidth=2)

    muVals = mu_hyb(urange,C0min,Kd,gamma,alpha,beta,N)
    axNaU.plot(urange,muVals,'--',linewidth=2)
   
    axNaU.set_xlabel(r'$u$',fontsize=18)
    axNaU.set_ylabel(r'$\langle n_{A} \rangle$',fontsize=18)

    figNaU.tight_layout()

    #-------------------------------------------------------------------------------------
    #-------------------------------------------------------------------------------------
    save_figs=False
    if save_figs:
        #fig.savefig("./Figures/MeanSurfaceProjection_ThetaUf.pdf",edgecolor='black')
        figP.savefig("./Figures/MeanSurfaceProjection_ThetaUf.pdf",edgecolor='black')
        #fig_cfu0.savefig("./Figures/MeanSurfaceProjection_ThetaCf.pdf",edgecolor='black')
        figPC.savefig("./Figures/MeanSurfaceProjection_ThetaCf.pdf",edgecolor='black')

    plt.show()
